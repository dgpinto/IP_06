﻿class ClaseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa, Dosificacion de horas laborales");
        Console.WriteLine();
        Console.WriteLine("Seleccione su horario de trabajo");
        Console.WriteLine();
        Console.WriteLine("Menu principal");
        Console.WriteLine("1. Despertina");
        Console.WriteLine("2. Matutina");
        string SeleccionMenu;
        SeleccionMenu = Console.ReadLine();

        switch (SeleccionMenu)
        {
            case "1":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + " Despertina");
                break;
            case "2":
                Console.WriteLine("Ud selecciono opcion: " + SeleccionMenu + " Matutina");
                break;
            default:
                Console.WriteLine("Selecione una opcion valida");
                break;
        }
        Console.ReadKey();
    }

    static int stmetodoDummy()
    {
        return 1;
    }
}