﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L8_DerickPinto_1065723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Dinero;
            double Billete100 = 0;
            double Billete50 = 0;
            double Billete20 = 0;
            double Billete10 = 0;
            double Billete5 = 0;
            double Moneda1 = 0;
            double Centavo25 = 0;
            double Centavo1 = 0;

            Console.WriteLine("Derick Pinto - 1065723");
            Console.WriteLine("Ingrese la cantidad: ");
            Dinero = Convert.ToDouble(Console.ReadLine());

            if (Dinero >= 100)
            {
                Billete100 = Dinero / 100;
                Dinero = Dinero % 100;
            }

            if (Dinero >= 50)
            {
                Billete50 = Dinero / 50;
                Dinero = Dinero % 50;

            }

            if (Dinero >= 20)
            {
                Billete20 = Dinero / 20;
                Dinero = Dinero % 20;
            }

            if (Dinero >= 10)
            {
                Billete10 = Dinero / 10;
                Dinero = Dinero % 10;
            }

            if (Dinero >= 5)
            {
                Billete5 = Dinero / 5;
                Dinero = Dinero % 5;
            }

            if (Dinero >= 1)
            {
                Moneda1 = Dinero / 1;
                Dinero = Dinero % 1;
            }

            if (Dinero >= 0.25)
            {
                Centavo25 = Dinero / 0.25;
                Dinero = Dinero % 0.25;
            }

            if (Dinero >= 0.01)
            {
                Centavo1 = Dinero / 0.01;
                Dinero = Dinero % 0.01;
            }

            Console.WriteLine("Usted necesita " + Math.Truncate(Billete100) + " Billetes de 100");
            Console.WriteLine("Usted necesita " + Math.Truncate(Billete50) + " Billetes de 50");
            Console.WriteLine("Usted necesita " + Math.Truncate(Billete20) + " Billetes de 20");
            Console.WriteLine("Usted necesita " + Math.Truncate(Billete10) + " Billetes de 10");
            Console.WriteLine("Usted necesita " + Math.Truncate(Billete5) + " Billetes de 5");
            Console.WriteLine("Usted necesita " + Math.Truncate(Moneda1) + " Monedas de 1");
            Console.WriteLine("Usted necesita " + Math.Truncate(Centavo25) + " centavos de 25");
            Console.WriteLine("Usted necesita " + Math.Truncate(Centavo1) + " centavos");

            Console.ReadKey();
        }
    }
}
