﻿namespace T1_Derick_Pinto_1065723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            string sNombre, sEdad, sCarrera, sCarne;
            Console.WriteLine("Ingrese Nombre");
            sNombre = Console.ReadLine();
            Console.WriteLine("Ingrese Edad");
            sEdad = Console.ReadLine();
            Console.WriteLine("Ingrese Carrera");
            sCarrera = Console.ReadLine();
            Console.WriteLine("Ingrese Carne");
            sCarne = Console.ReadLine();

            Console.WriteLine("Nombre; " +  sNombre);
            Console.WriteLine("Edad; " + sEdad);
            Console.WriteLine("Carrera; " + sCarrera);
            Console.WriteLine("Carne; " + sCarne);

            Console.WriteLine("Soy " + sNombre + " Tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " Mi numero de carnet es " + sCarne);
            Console.ReadLine();
        }
    }
}