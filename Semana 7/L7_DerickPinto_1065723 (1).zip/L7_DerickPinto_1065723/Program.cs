﻿using System.ComponentModel.Design;

namespace Ejercicio1
{
    class program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1");

            int num1 =0;
            Console.WriteLine("Ingrese un numero ENTERO");
            num1 = Int32.Parse(Console.ReadLine());

            if (num1 >0)
            {
                Console.WriteLine("Su numero es POSITIVO");
            }
            else if (num1 <0)
            {
                Console.WriteLine("Su numero es Negativo");
            }
            

            else if (num1 == 0) 
            {
                Console.WriteLine("Su numero es IGUAL A 0");
            }

            Console.ReadKey();
            Console.Clear();

            //Ejercicio 2

            Console.WriteLine("Ejercicio 2");

            Console.WriteLine("Ingrese un numero del dia de la semana");

            string SeleccineDia;
            SeleccineDia = Console.ReadLine();



            switch (SeleccineDia)
            {
                case "1":
                    Console.WriteLine("Ud selecciono el dia Lunes");
                    break;
                case "2":
                    Console.WriteLine("Ud selecciono el dia Martes");
                    break;
                case "3":
                    Console.WriteLine("Ud selecciono el dia Miercoles");
                    break;
                case "4":
                    Console.WriteLine("Ud selecciono el dia Jueves");
                    break;
                case "5":
                    Console.WriteLine("Ud selecciono el dia Vinernes");
                    break;
                case "6":
                    Console.WriteLine("Ud selecciono el dia Sabado");
                    break;
                case "7":
                    Console.WriteLine("Ud selecciono el dia Domingo");
                    break;
                default:
                    Console.WriteLine("Seleccione un numero del 1 al 7");
                    break;
            }
            Console.ReadKey();
        }
    }
}
